// background.js — GCN Auto Uploader

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['uploadHistory'], r => {
    if (!r.uploadHistory) chrome.storage.local.set({ uploadHistory: {} });
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // Lấy danh sách tên file đã upload hôm nay
  if (msg.type === 'GET_TODAY') {
    const key = todayKey();
    chrome.storage.local.get(['uploadHistory'], r => {
      const h = r.uploadHistory || {};
      sendResponse({ names: (h[key] || []).map(f => f.name) });
    });
    return true;
  }

  // Thêm file vào lịch sử
  if (msg.type === 'ADD_HISTORY') {
    const key = todayKey();
    chrome.storage.local.get(['uploadHistory'], r => {
      const h = r.uploadHistory || {};
      if (!h[key]) h[key] = [];
      h[key].push({ name: msg.name, time: new Date().toISOString(), status: msg.status });
      // Dọn lịch sử cũ > 30 ngày
      const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
      for (const k in h) { if (new Date(k) < cutoff) delete h[k]; }
      chrome.storage.local.set({ uploadHistory: h });
      sendResponse({ ok: true });
    });
    return true;
  }

  // Lấy toàn bộ lịch sử hôm nay (kèm thông tin đầy đủ)
  if (msg.type === 'GET_TODAY_FULL') {
    const key = todayKey();
    chrome.storage.local.get(['uploadHistory'], r => {
      const h = r.uploadHistory || {};
      sendResponse({ files: h[key] || [] });
    });
    return true;
  }

  // Xóa lịch sử hôm nay
  if (msg.type === 'CLEAR_TODAY') {
    const key = todayKey();
    chrome.storage.local.get(['uploadHistory'], r => {
      const h = r.uploadHistory || {};
      delete h[key];
      chrome.storage.local.set({ uploadHistory: h }, () => sendResponse({ ok: true }));
    });
    return true;
  }
});

function todayKey() {
  return new Date().toISOString().split('T')[0];
}
