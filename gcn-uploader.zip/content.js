// content.js — chạy trên trang quantrigcn.vr.org.vn
// Lắng nghe lệnh từ popup, điều khiển luồng upload tự động

const BATCH_SIZE = 5; // Giới hạn của website: tối đa 5 file / lần

// ── Lắng nghe message từ popup ──────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'PING') {
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === 'START_UPLOAD') {
    handleUpload(msg.files, msg.settings)
      .then(result => sendResponse({ ok: true, result }))
      .catch(err   => sendResponse({ ok: false, error: err.message }));
    return true; // async
  }
});

// ── Luồng upload chính ───────────────────────────────────────────────────────
async function handleUpload(fileDataList, settings) {
  const results = { success: [], skipped: [], renamed: [], batches: 0 };

  // 1. Lấy tên đã upload hôm nay
  const todayNames = await getTodayNames();

  // 2. Lọc & chuẩn bị toàn bộ danh sách
  const toUpload = [];

  for (const fd of fileDataList) {
    const original = fd.name;
    const ext  = getExt(original);
    const base = getBase(original);

    // Lọc "bs"
    if (settings.filterBs) {
      const checkBase = settings.caseSensitive ? base : base.toLowerCase();
      if (checkBase.includes('bs')) {
        if (settings.errorAction === 'rename') {
          const cleaned = settings.caseSensitive
            ? base.replace(/bs/g, '') : base.replace(/bs/gi, '');
          fd.uploadName = (cleaned || 'file') + ext;
          fd.reason = 'bs_removed';
        } else {
          results.skipped.push({ name: original, reason: 'Tên chứa "bs"' });
          await addHistory(original, 'skipped');
          continue;
        }
      }
    }

    if (!fd.uploadName) fd.uploadName = original;

    // Kiểm tra trùng tên
    if (settings.checkDuplicate) {
      const isDup = todayNames.some(n => {
        const a = settings.caseSensitive ? n : n.toLowerCase();
        const b = settings.caseSensitive ? fd.uploadName : fd.uploadName.toLowerCase();
        return a === b;
      });
      if (isDup) {
        if (settings.errorAction === 'rename') {
          fd.uploadName = settings.renamePrefix + fd.uploadName;
          fd.reason = (fd.reason ? fd.reason + '+' : '') + 'renamed';
        } else {
          results.skipped.push({ name: original, reason: 'Trùng tên hôm nay' });
          await addHistory(original, 'skipped');
          continue;
        }
      }
    }

    toUpload.push(fd);
  }

  if (toUpload.length === 0) {
    return { ...results, message: 'Không có file nào hợp lệ để upload.' };
  }

  // 3. Chia thành các batch 5 ảnh, upload tuần tự
  const batches = chunkArray(toUpload, BATCH_SIZE);
  results.batches = batches.length;

  for (let i = 0; i < batches.length; i++) {
    const batch = batches[i];

    // Thông báo tiến độ batch lên popup
    chrome.runtime.sendMessage({
      type: 'BATCH_PROGRESS',
      current: i + 1,
      total: batches.length,
      count: batch.length,
    });

    try {
      await uploadBatch(batch);

      // Ghi lịch sử cho batch vừa xong
      for (const fd of batch) {
        await addHistory(fd.uploadName, 'success');
        results.success.push(fd.uploadName);
        // Chỉ push vào renamed nếu tên thực sự thay đổi
        if (fd.reason && fd.uploadName !== fd.name) {
          results.renamed.push({ from: fd.name, to: fd.uploadName });
        }
        // Thêm vào todayNames để batch sau không trùng
        todayNames.push(fd.uploadName);
      }
    } catch (err) {
      for (const fd of batch) {
        results.skipped.push({ name: fd.uploadName, reason: `Lỗi đợt ${i + 1}: ${err.message}` });
        await addHistory(fd.uploadName, 'failed');
      }
    }

    // Nghỉ giữa các batch để trang xử lý xong
    if (i < batches.length - 1) await sleep(1000);
  }

  const batchNote = batches.length > 1 ? ` (${batches.length} đợt × ${BATCH_SIZE})` : '';
  return {
    ...results,
    message: `✓ Đã upload ${results.success.length} file thành công${batchNote}.`
      + (results.skipped.length ? ` Bỏ qua/lỗi: ${results.skipped.length} file.` : '')
      + (results.renamed.length ? ` Đổi tên: ${results.renamed.length} file.` : ''),
  };
}

// ── Upload 1 batch (tối đa BATCH_SIZE file) ──────────────────────────────────
async function uploadBatch(batch) {
  // Đảm bảo dialog cũ đã đóng hẳn trước khi bắt đầu
  await waitFor(() => !findUploadDialog(), 3000);

  // Click "Up files"
  const upBtn = findUpFilesButton();
  if (!upBtn) throw new Error('Không tìm thấy nút "Up files". Hãy vào trang Quản lý file.');

  upBtn.click();
  await sleep(900);

  // Chờ dialog xuất hiện
  const dialog = await waitFor(() => findUploadDialog(), 5000);
  if (!dialog) throw new Error('Dialog upload không xuất hiện.');

  // Tìm input file trong dialog (hoặc toàn trang nếu dialog dùng teleport/portal)
  const fileInput = dialog.querySelector('input[type="file"]')
    || document.querySelector('input[type="file"]');
  if (!fileInput) throw new Error('Không tìm thấy ô chọn file trong dialog.');

  // Inject file vào input
  const fileObjects = batch.map(fd => dataUrlToFile(fd.dataUrl, fd.uploadName, fd.type));
  const dt = new DataTransfer();
  fileObjects.forEach(f => dt.items.add(f));
  fileInput.files = dt.files;
  fileInput.dispatchEvent(new Event('change', { bubbles: true }));
  fileInput.dispatchEvent(new Event('input',  { bubbles: true }));
  await sleep(700);

  // Click nút "Upload" trong dialog
  const uploadBtn = findUploadButton(dialog);
  if (!uploadBtn) throw new Error('Không tìm thấy nút "Upload" trong dialog.');

  uploadBtn.click();

  // Chờ upload hoàn thành: dialog đóng HOẶC xuất hiện thông báo thành công
  const done = await waitFor(() => {
    const d = findUploadDialog();
    if (!d) return true;                    // dialog đã đóng
    if (isUploadComplete(d)) {
      closeDialog(d);                       // tự đóng nếu trang không tự đóng
      return true;
    }
    return false;
  }, 25000);

  if (!done) throw new Error('Upload quá thời gian chờ (25s). Vui lòng thử lại.');

  // Thêm delay nhỏ để trang refresh danh sách
  await sleep(600);
}

// ── Đóng dialog thủ công ─────────────────────────────────────────────────────
function closeDialog(dialog) {
  // Thử click nút "Thoát" / "Close" / "×"
  const closeSelectors = [
    'button[aria-label="Close"]', 'button[aria-label="close"]',
    '.btn-close', '.close', '[data-dismiss="modal"]',
    'button.close', '.modal-close',
  ];
  for (const s of closeSelectors) {
    const btn = dialog.querySelector(s) || document.querySelector(s);
    if (btn && isVisible(btn)) { btn.click(); return; }
  }
  // Fallback: tìm nút có text "Thoát" hoặc "Đóng"
  const all = dialog.querySelectorAll('button, a');
  for (const el of all) {
    const txt = el.innerText?.trim().toLowerCase() || '';
    if (txt === 'thoát' || txt === 'đóng' || txt === 'close' || txt === '×') {
      el.click(); return;
    }
  }
}

// ── Tìm phần tử trên trang ───────────────────────────────────────────────────
function findUpFilesButton() {
  const candidates = document.querySelectorAll('button, a, [role="button"], span[onclick], div[onclick]');
  for (const el of candidates) {
    const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
    if (txt.includes('up files') || txt === 'up files') return el;
    const title = (el.getAttribute('title') || '').toLowerCase();
    if (title.includes('up files')) return el;
    const ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();
    if (ariaLabel.includes('up files')) return el;
  }
  return null;
}

function findUploadDialog() {
  // Ưu tiên: tìm theo text đặc trưng của dialog website này
  const allDivs = document.querySelectorAll('div, section, aside');
  for (const d of allDivs) {
    const txt = d.innerText || '';
    if (txt.includes('Chọn file để upload') && isVisible(d)) return d;
    if (txt.includes('Số file / lần') && isVisible(d)) return d;
  }
  // Fallback: tìm modal/dialog chung
  const genericSelectors = [
    '[role="dialog"]', '.modal.show', '.modal.active',
    '[class*="modal"][class*="show"]', '[class*="modal"][class*="active"]',
    '[class*="dialog"][class*="show"]', '[class*="dialog"][class*="open"]',
  ];
  for (const s of genericSelectors) {
    const el = document.querySelector(s);
    if (el && isVisible(el)) return el;
  }
  return null;
}

function findUploadButton(dialog) {
  const container = dialog || document;
  // Tìm nút "Upload" — không lấy nhầm nút "Up files" ngoài dialog
  const all = container.querySelectorAll('button, [role="button"], a.btn, a.button');
  for (const el of all) {
    const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
    if (txt === 'upload') return el;
  }
  // Fallback: nút có chứa "upload"
  for (const el of all) {
    const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
    if (txt.includes('upload') && !txt.includes('up files')) return el;
  }
  return null;
}

function isUploadComplete(dialog) {
  const txt = (dialog.innerText || '').toLowerCase();
  return txt.includes('thành công') || txt.includes('upload thành công')
    || txt.includes('hoàn thành') || txt.includes('success') || txt.includes('complete');
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function isVisible(el) {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);
  return r.width > 0 && r.height > 0
    && style.display !== 'none'
    && style.visibility !== 'hidden'
    && style.opacity !== '0';
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function waitFor(fn, timeout = 5000, interval = 200) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const result = fn();
    if (result) return result;
    await sleep(interval);
  }
  return null;
}

function chunkArray(arr, size) {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) chunks.push(arr.slice(i, i + size));
  return chunks;
}

function getExt(name)  { const i = name.lastIndexOf('.'); return i >= 0 ? name.slice(i) : ''; }
function getBase(name) { const i = name.lastIndexOf('.'); return i >= 0 ? name.slice(0, i) : name; }

function dataUrlToFile(dataUrl, fileName, mimeType) {
  const arr  = dataUrl.split(',');
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8 = new Uint8Array(n);
  while (n--) u8[n] = bstr.charCodeAt(n);
  return new File([u8], fileName, { type: mimeType || 'image/jpeg' });
}

async function getTodayNames() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'GET_TODAY' }, r => resolve(r?.names || []));
  });
}

async function addHistory(name, status) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'ADD_HISTORY', name, status }, resolve);
  });
}
