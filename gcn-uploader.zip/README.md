# GCN Auto Uploader — Edge Extension
> Tự động upload ảnh lên **quantrigcn.vr.org.vn** với kiểm tra tên thông minh

---

## 🚀 Cài vào Edge

1. Giải nén file `gcn-uploader.zip`
2. Mở Edge → địa chỉ: **`edge://extensions/`**
3. Bật **Developer mode** (góc dưới trái)
4. Nhấn **"Load unpacked"** → chọn thư mục `gcn-uploader`
5. Extension xuất hiện trên thanh công cụ ✅

---

## 📋 Cách dùng

1. Đăng nhập vào `quantrigcn.vr.org.vn` → vào **Quản lý file**
2. Nhấn icon extension trên thanh công cụ
3. **Chấm xanh** = đã kết nối với trang ✓
4. Kéo thả hoặc nhấn **"chọn ảnh"** để thêm ảnh
5. Kiểm tra danh sách:
   - ✅ **OK** — hợp lệ, sẽ upload
   - 🔴 **Có "bs"** — tên chứa ký tự bị lọc
   - 🟡 **Trùng tên** — đã upload hôm nay
   - 🔵 **Đổi tên** — tự động đổi tên (nếu bật)
6. Nhấn **"Upload N ảnh"**
7. Extension tự động:
   - Click nút **"Up files"** trên trang
   - Inject file đã lọc vào dialog upload
   - Click **"Upload"**
   - Hiện kết quả ✓

---

## ⚙️ Cài đặt

| Tùy chọn | Mô tả |
|----------|-------|
| Lọc ký tự "bs" | Bỏ qua hoặc tự xóa "bs" khỏi tên file |
| Chống trùng tên | So với danh sách đã upload trong ngày |
| Phân biệt hoa/thường | abc.jpg ≠ ABC.jpg |
| Hành động khi lỗi | **Bỏ qua** file đó / **Tự đổi tên** |
| Prefix đổi tên | Thêm vào đầu tên file khi đổi (vd: `copy_`) |

---

## 🔧 Giới hạn kỹ thuật website

Website cho phép upload tối đa **5 file / lần**, mỗi file **≤ 20 MB**.
Extension tự chia batch nếu cần trong phiên bản tương lai.

---

## 📂 Cấu trúc

```
gcn-uploader/
├── manifest.json     # Manifest V3, chỉ chạy trên quantrigcn.vr.org.vn
├── background.js     # Service worker — lưu lịch sử upload
├── content.js        # Chạy trên trang — điều khiển click & inject file
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── popup/
    ├── popup.html
    ├── popup.css
    └── popup.js
```
