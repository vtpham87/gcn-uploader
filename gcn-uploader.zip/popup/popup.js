/* GCN Auto Uploader - Protected Build
 * (c) 2026 GCN Uploader. All rights reserved.
 * Unauthorized copying or redistribution is prohibited.
 */
const BATCH_SIZE = 5;
let queue = []; 
let todayNames = []; 
let settings = {
 filterBs: true, checkDuplicate: true, caseSensitive: false,
 errorAction: '\u0073\u006b\u0069\u0070', renamePrefix: '\u0063\u006f\u0070\u0079\u005f',
};
const $ = id => document.getElementById(id);
document.addEventListener('\u0044\u004f\u004d\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u004c\u006f\u0061\u0064\u0065\u0064', async () => {
 await loadSettings();
 await loadTodayNames();
 applySettingsUI();
 renderHistory();
 setupListeners();
 checkConnection();
 restoreFolderPath();
 loadExtInfo();
});
const GCN_URL = 'https://quantrigcn.vr.org.vn/quan-ly-file';
async function checkConnection() {
 const dot = $('\u0073\u0074\u0061\u0074\u0075\u0073\u0044\u006f\u0074');
 const notice = $('\u006e\u006f\u0074\u0069\u0063\u0065\u004e\u006f\u0054\u0061\u0062');
 try {
 const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
 const url = tab?.url || '';
 const onSite = url.includes('\u0071\u0075\u0061\u006e\u0074\u0072\u0069\u0067\u0063\u006e\u002e\u0076\u0072\u002e\u006f\u0072\u0067\u002e\u0076\u006e');
 if (!onSite) {
 dot.className = '\u0073\u0074\u0061\u0074\u0075\u0073\u002d\u0064\u006f\u0074\u0020\u0064\u0069\u0073\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0065\u0064';
 notice.style.display = '\u0062\u006c\u006f\u0063\u006b';
 await navigateToGCN();
 return;
 }
 if (!url.includes('/quan-ly-file')) {
 await navigateToGCN(tab.id);
 }
 chrome.tabs.sendMessage(tab.id, { type: '\u0050\u0049\u004e\u0047' }, async resp => {
 if (!chrome.runtime.lastError && resp?.ok) {
 dot.className = '\u0073\u0074\u0061\u0074\u0075\u0073\u002d\u0064\u006f\u0074\u0020\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0065\u0064';
 notice.style.display = '\u006e\u006f\u006e\u0065';
 return;
 }
 try {
 await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u006a\u0073'] });
 await sleep(400);
 chrome.tabs.sendMessage(tab.id, { type: '\u0050\u0049\u004e\u0047' }, resp2 => {
 if (!chrome.runtime.lastError && resp2?.ok) {
 dot.className = '\u0073\u0074\u0061\u0074\u0075\u0073\u002d\u0064\u006f\u0074\u0020\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0065\u0064';
 notice.style.display = '\u006e\u006f\u006e\u0065';
 } else {
 dot.className = '\u0073\u0074\u0061\u0074\u0075\u0073\u002d\u0064\u006f\u0074\u0020\u0064\u0069\u0073\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0065\u0064';
 notice.style.display = '\u0062\u006c\u006f\u0063\u006b';
 }
 });
 } catch { dot.className = '\u0073\u0074\u0061\u0074\u0075\u0073\u002d\u0064\u006f\u0074\u0020\u0064\u0069\u0073\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0065\u0064'; notice.style.display = '\u0062\u006c\u006f\u0063\u006b'; }
 });
 } catch { dot.className = '\u0073\u0074\u0061\u0074\u0075\u0073\u002d\u0064\u006f\u0074\u0020\u0064\u0069\u0073\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0065\u0064'; }
}
async function navigateToGCN(existingTabId = null) {
 if (existingTabId) {
 await chrome.tabs.update(existingTabId, { url: GCN_URL });
 } else {
 const gcnTabs = await chrome.tabs.query({ url: '*://quantrigcn.vr.org.vn/*' });
 if (gcnTabs.length > 0) {
 await chrome.tabs.update(gcnTabs[0].id, { url: GCN_URL, active: true });
 await chrome.windows.update(gcnTabs[0].windowId, { focused: true });
 } else {
 await chrome.tabs.create({ url: GCN_URL });
 }
 }
 await sleep(2000);
 const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
 if (tab) {
 try {
 await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u006a\u0073'] });
 $('\u0073\u0074\u0061\u0074\u0075\u0073\u0044\u006f\u0074').className = '\u0073\u0074\u0061\u0074\u0075\u0073\u002d\u0064\u006f\u0074\u0020\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0065\u0064';
 $('\u006e\u006f\u0074\u0069\u0063\u0065\u004e\u006f\u0054\u0061\u0062').style.display = '\u006e\u006f\u006e\u0065';
 } catch (_) {}
 }
}
async function ensureContentScript(tabId) {
 return new Promise(resolve => {
 chrome.tabs.sendMessage(tabId, { type: '\u0050\u0049\u004e\u0047' }, async resp => {
 if (!chrome.runtime.lastError && resp?.ok) { resolve(); return; }
 try {
 await chrome.scripting.executeScript({ target: { tabId }, files: ['\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u006a\u0073'] });
 await sleep(400);
 } catch (_) {}
 resolve();
 });
 });
}
function restoreFolderPath() {
 chrome.storage.local.get(['\u006c\u0061\u0073\u0074\u0046\u006f\u006c\u0064\u0065\u0072\u0050\u0061\u0074\u0068'], res => setFolderPathUI(res.lastFolderPath || ''));
}
function setFolderPathUI(path) {
 const el = $('\u0066\u006f\u006c\u0064\u0065\u0072\u0050\u0061\u0074\u0068');
 if (path) { el.textContent = path; el.classList.remove('\u0065\u006d\u0070\u0074\u0079'); }
 else { el.textContent = 'Chưa chọn thư mục'; el.classList.add('\u0065\u006d\u0070\u0074\u0079'); }
}
function getFolderName(files) {
 if (!files.length) return '';
 return files.length > 1
 ? `${files[0].name} (+${files.length - 1} file)`
 : files[0].name;
}
async function scanAndQueue(files) {
 queue = [];
 $('\u0072\u0065\u0073\u0075\u006c\u0074\u0042\u006f\u0078').hidden = true;
 const allImages = Array.from(files).filter(f => f.type.startsWith('image/'));
 if (!allImages.length) {
 showScanMsg('Không tìm thấy ảnh nào trong thư mục.', '\u0077\u0061\u0072\u006e');
 renderQueue(); updateBtn(); return;
 }
 let countNew = 0, countSkipDup = 0, countSkipBs = 0, countRenamed = 0;
 for (const file of allImages) {
 const v = validate(file.name);
 if (!v.valid) {
 if (v.status === 'bs') countSkipBs++;
 if (v.status === '\u0064\u0075\u0070') countSkipDup++;
 continue;
 }
 if (v.status === '\u0072\u0065\u006e\u0061\u006d\u0065\u0064') countRenamed++;
 const dataUrl = await readDataUrl(file);
 queue.push({
 id: Date.now() + Math.random(),
 file, dataUrl,
 originalName: file.name,
 uploadName: v.uploadName,
 status: v.status,
 valid: true,
 });
 countNew++;
 }
 const parts = [];
 if (countNew > 0) parts.push(`<span class="\u0073\u002d\u006f\u006b">✓ ${countNew} ảnh mới</span>`);
 if (countSkipDup > 0) parts.push(`<span class="\u0073\u002d\u0073\u006b\u0069\u0070">${countSkipDup} trùng tên</span>`);
 if (countSkipBs > 0) parts.push(`<span class="\u0073\u002d\u0073\u006b\u0069\u0070">${countSkipBs} có "bs"</span>`);
 if (countRenamed > 0) parts.push(`<span class="\u0073\u002d\u0072\u0065\u006e\u0061\u006d\u0065">${countRenamed} đổi tên</span>`);
 if (countNew === 0) parts.unshift('<span class="\u0073\u002d\u0077\u0061\u0072\u006e">Không có ảnh mới nào</span>');
 $('\u0073\u0063\u0061\u006e\u0053\u0075\u006d\u006d\u0061\u0072\u0079').hidden = false;
 $('\u0073\u0063\u0061\u006e\u004d\u0073\u0067').innerHTML = parts.join(' · ');
 renderQueue();
 updateBtn();
}
function showScanMsg(msg, type) {
 $('\u0073\u0063\u0061\u006e\u0053\u0075\u006d\u006d\u0061\u0072\u0079').hidden = false;
 $('\u0073\u0063\u0061\u006e\u004d\u0073\u0067').innerHTML = `<span class="s-${type}">${msg}</span>`;
}
async function loadSettings() {
 return new Promise(r => {
 chrome.storage.local.get(['\u0067\u0063\u006e\u0053\u0065\u0074\u0074\u0069\u006e\u0067\u0073'], res => {
 if (res.gcnSettings) Object.assign(settings, res.gcnSettings);
 r();
 });
 });
}
function applySettingsUI() {
 $('\u0066\u0069\u006c\u0074\u0065\u0072\u0042\u0073').checked = settings.filterBs;
 $('\u0063\u0068\u0065\u0063\u006b\u0044\u0075\u0070\u006c\u0069\u0063\u0061\u0074\u0065').checked = settings.checkDuplicate;
 $('\u0063\u0061\u0073\u0065\u0053\u0065\u006e\u0073\u0069\u0074\u0069\u0076\u0065').checked = settings.caseSensitive;
 $('\u0065\u0072\u0072\u006f\u0072\u0041\u0063\u0074\u0069\u006f\u006e').value = settings.errorAction;
 $('\u0072\u0065\u006e\u0061\u006d\u0065\u0050\u0072\u0065\u0066\u0069\u0078').value = settings.renamePrefix;
 togglePrefixRow();
}
function saveSettings() {
 settings.filterBs = $('\u0066\u0069\u006c\u0074\u0065\u0072\u0042\u0073').checked;
 settings.checkDuplicate = $('\u0063\u0068\u0065\u0063\u006b\u0044\u0075\u0070\u006c\u0069\u0063\u0061\u0074\u0065').checked;
 settings.caseSensitive = $('\u0063\u0061\u0073\u0065\u0053\u0065\u006e\u0073\u0069\u0074\u0069\u0076\u0065').checked;
 settings.errorAction = $('\u0065\u0072\u0072\u006f\u0072\u0041\u0063\u0074\u0069\u006f\u006e').value;
 settings.renamePrefix = $('\u0072\u0065\u006e\u0061\u006d\u0065\u0050\u0072\u0065\u0066\u0069\u0078').value || '\u0063\u006f\u0070\u0079\u005f';
 chrome.storage.local.set({ gcnSettings: settings });
 toast('✓ Đã lưu cài đặt');
}
function togglePrefixRow() {
 $('\u0070\u0072\u0065\u0066\u0069\u0078\u0052\u006f\u0077').style.display = $('\u0065\u0072\u0072\u006f\u0072\u0041\u0063\u0074\u0069\u006f\u006e').value === '\u0072\u0065\u006e\u0061\u006d\u0065' ? '\u0066\u006c\u0065\u0078' : '\u006e\u006f\u006e\u0065';
}
async function loadTodayNames() {
 return new Promise(r => {
 chrome.runtime.sendMessage({ type: '\u0047\u0045\u0054\u005f\u0054\u004f\u0044\u0041\u0059' }, res => {
 todayNames = res?.names || [];
 r();
 });
 });
}
function renderHistory() {
 $('\u0068\u0069\u0073\u0074\u0044\u0061\u0074\u0065').textContent = new Date().toLocaleDateString('\u0076\u0069\u002d\u0056\u004e',
 { weekday: '\u006c\u006f\u006e\u0067', day: '2-digit', month: '2-digit', year: '\u006e\u0075\u006d\u0065\u0072\u0069\u0063' });
 chrome.runtime.sendMessage({ type: '\u0047\u0045\u0054\u005f\u0054\u004f\u0044\u0041\u0059\u005f\u0046\u0055\u004c\u004c' }, res => {
 const files = res?.files || [];
 $('\u0068\u0069\u0073\u0074\u0053\u0075\u0062').textContent = `${files.length} file hôm nay`;
 const list = $('\u0068\u0069\u0073\u0074\u004c\u0069\u0073\u0074');
 list.innerHTML = '';
 if (!files.length) {
 list.innerHTML = '<li class="\u0068\u0069\u0073\u0074\u002d\u0065\u006d\u0070\u0074\u0079">Chưa có file nào được upload hôm nay</li>';
 return;
 }
 const grouped = {};
 files.forEach(f => {
 const h = new Date(f.time).toLocaleTimeString('\u0076\u0069\u002d\u0056\u004e', { hour: '2-digit', minute: '2-digit' });
 if (!grouped[h]) grouped[h] = [];
 grouped[h].push(f);
 });
 Object.keys(grouped).reverse().forEach(hour => {
 const grp = grouped[hour];
 const header = document.createElement('li');
 header.className = '\u0068\u0069\u0073\u0074\u002d\u0067\u0072\u006f\u0075\u0070\u002d\u0068\u0065\u0061\u0064\u0065\u0072';
 header.textContent = `${hour} · ${grp.length} file`;
 list.appendChild(header);
 grp.forEach(f => {
 const li = document.createElement('li');
 li.className = '\u0068\u0069\u0073\u0074\u002d\u0069\u0074\u0065\u006d';
 const dotCls = f.status === '\u0073\u0075\u0063\u0063\u0065\u0073\u0073' ? 'ok' : f.status === '\u0073\u006b\u0069\u0070\u0070\u0065\u0064' ? '\u0073\u006b\u0069\u0070' : '\u0065\u0072\u0072';
 li.innerHTML = `
 <div class="hi-dot ${dotCls}"></div>
 <span class="\u0068\u0069\u002d\u006e\u0061\u006d\u0065" title="${esc(f.name)}">${esc(f.name)}</span>`;
 list.appendChild(li);
 });
 });
 });
}
function validate(originalName) {
 const ext = getExt(originalName);
 const base = getBase(originalName);
 if (settings.filterBs) {
 const b = settings.caseSensitive ? base : base.toLowerCase();
 if (b.includes('bs')) {
 if (settings.errorAction === '\u0072\u0065\u006e\u0061\u006d\u0065') {
 const cleaned = (settings.caseSensitive ? base.replace(/bs/g,'') : base.replace(/bs/gi,'')) || '\u0066\u0069\u006c\u0065';
 return dupCheck(cleaned + ext, originalName, '\u0072\u0065\u006e\u0061\u006d\u0065\u0064');
 }
 return { valid: false, status: 'bs', uploadName: originalName };
 }
 }
 return dupCheck(originalName, originalName, 'ok');
}
function dupCheck(name, originalName, prevStatus) {
 if (!settings.checkDuplicate)
 return { valid: true, status: prevStatus, uploadName: name };
 const dup = todayNames.some(n => {
 const a = settings.caseSensitive ? n : n.toLowerCase();
 const b = settings.caseSensitive ? name : name.toLowerCase();
 return a === b;
 });
 if (dup) {
 if (settings.errorAction === '\u0072\u0065\u006e\u0061\u006d\u0065')
 return { valid: true, status: '\u0072\u0065\u006e\u0061\u006d\u0065\u0064', uploadName: settings.renamePrefix + name };
 return { valid: false, status: '\u0064\u0075\u0070', uploadName: name };
 }
 return { valid: true, status: prevStatus, uploadName: name };
}
function renderQueue() {
 const wrap = $('\u0071\u0075\u0065\u0075\u0065\u0057\u0072\u0061\u0070');
 if (!queue.length) { wrap.hidden = true; return; }
 wrap.hidden = false;
 const n = queue.length;
 const batchN = Math.ceil(n / BATCH_SIZE);
 $('\u0062\u0061\u0064\u0067\u0065\u0054\u006f\u0074\u0061\u006c').textContent = n;
 $('\u006f\u006b\u0043\u006f\u0075\u006e\u0074').textContent = `${n} ảnh`;
 const bc = $('\u0062\u0061\u0074\u0063\u0068\u0043\u006f\u0075\u006e\u0074');
 if (batchN > 1) { bc.textContent = `${batchN} đợt`; bc.hidden = false; }
 else bc.hidden = true;
 $('\u0073\u006b\u0069\u0070\u0043\u006f\u0075\u006e\u0074').hidden = true;
 const list = $('\u0066\u0069\u006c\u0065\u004c\u0069\u0073\u0074');
 list.innerHTML = '';
 queue.forEach((item, idx) => {
 if (idx > 0 && idx % BATCH_SIZE === 0) {
 const div = document.createElement('li');
 div.className = '\u0062\u0061\u0074\u0063\u0068\u002d\u0064\u0069\u0076\u0069\u0064\u0065\u0072';
 div.textContent = `— Đợt ${Math.floor(idx / BATCH_SIZE) + 1} —`;
 list.appendChild(div);
 }
 const li = document.createElement('li');
 li.className = '\u0066\u0069\u006c\u0065\u002d\u0069\u0074\u0065\u006d';
 const url = URL.createObjectURL(item.file);
 const bd = badgeInfo(item.status);
 const nameHtml = item.uploadName !== item.originalName
 ? `${esc(item.uploadName)} <em class="\u006f\u0072\u0069\u0067\u002d\u006e\u0061\u006d\u0065">(← ${esc(item.originalName)})</em>`
 : esc(item.uploadName);
 li.innerHTML = `
 <img class="\u0066\u0069\u002d\u0074\u0068\u0075\u006d\u0062" src="${url}" />
 <div class="\u0066\u0069\u002d\u0069\u006e\u0066\u006f">
 <div class="fi-name ${item.status === '\u0072\u0065\u006e\u0061\u006d\u0065\u0064' ? '\u0072\u0065\u006e\u0061\u006d\u0065\u0064' : ''}">${nameHtml}</div>
 <div class="\u0066\u0069\u002d\u006d\u0065\u0074\u0061">${fmtSize(item.file.size)}</div>
 </div>
 <span class="fi-badge ${bd.cls}">${bd.text}</span>
 <button class="\u0062\u0074\u006e\u002d\u0072\u006d" title="Xóa">×</button>`;
 li.querySelector('.btn-rm').onclick = () => {
 queue = queue.filter(q => q.id !== item.id);
 URL.revokeObjectURL(url);
 renderQueue(); updateBtn();
 };
 list.appendChild(li);
 });
}
function updateBtn() {
 const n = queue.length;
 $('\u0062\u0074\u006e\u0055\u0070\u006c\u006f\u0061\u0064').disabled = n === 0;
 if (n === 0) {
 $('\u0062\u0074\u006e\u0055\u0070\u006c\u006f\u0061\u0064\u0054\u0065\u0078\u0074').textContent = '\u0055\u0070\u006c\u006f\u0061\u0064';
 return;
 }
 const b = Math.ceil(n / BATCH_SIZE);
 $('\u0062\u0074\u006e\u0055\u0070\u006c\u006f\u0061\u0064\u0054\u0065\u0078\u0074').textContent = b > 1
 ? `Upload ${n} ảnh (${b} đợt × ${BATCH_SIZE})`
 : `Upload ${n} ảnh`;
}
chrome.runtime.onMessage.addListener((msg) => {
 if (msg.type === '\u0042\u0041\u0054\u0043\u0048\u005f\u0050\u0052\u004f\u0047\u0052\u0045\u0053\u0053')
 $('\u0062\u0074\u006e\u0055\u0070\u006c\u006f\u0061\u0064\u0054\u0065\u0078\u0074').textContent = `Đợt ${msg.current}/${msg.total} — ${msg.count} ảnh…`;
});
async function startUpload() {
 if (!queue.length) return;
 const btn = $('\u0062\u0074\u006e\u0055\u0070\u006c\u006f\u0061\u0064');
 btn.classList.add('\u0062\u0075\u0073\u0079');
 btn.disabled = true;
 $('\u0072\u0065\u0073\u0075\u006c\u0074\u0042\u006f\u0078').hidden = true;
 const totalBatches = Math.ceil(queue.length / BATCH_SIZE);
 $('\u0062\u0074\u006e\u0055\u0070\u006c\u006f\u0061\u0064\u0054\u0065\u0078\u0074').textContent = totalBatches > 1 ? `Chuẩn bị ${totalBatches} đợt…` : 'Đang upload…';
 try {
 const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
 if (!tab) throw new Error('Không tìm thấy tab GCN đang mở.');
 await ensureContentScript(tab.id);
 const filesPayload = queue.map(item => ({
 name: item.originalName,
 dataUrl: item.dataUrl,
 type: item.file.type,
 size: item.file.size,
 }));
 const response = await new Promise((resolve, reject) => {
 chrome.tabs.sendMessage(tab.id, { type: '\u0053\u0054\u0041\u0052\u0054\u005f\u0055\u0050\u004c\u004f\u0041\u0044', files: filesPayload, settings }, res => {
 if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
 else resolve(res);
 });
 });
 if (!response?.ok) throw new Error(response?.error || 'Lỗi không xác định');
 const result = response.result;
 showResult(result);
 const doneSet = new Set(result.success);
 queue = queue.filter(q => !doneSet.has(q.uploadName) && !doneSet.has(q.originalName));
 await loadTodayNames();
 renderQueue();
 renderHistory();
 if (result.success?.length)
 showScanMsg(`✓ Đã upload ${result.success.length} ảnh — ${new Date().toLocaleTimeString('\u0076\u0069\u002d\u0056\u004e', {hour:'2-digit',minute:'2-digit'})}`, 'ok');
 } catch (err) {
 showResult({ error: err.message });
 }
 btn.classList.remove('\u0062\u0075\u0073\u0079');
 updateBtn();
}
function showResult(result) {
 const box = $('\u0072\u0065\u0073\u0075\u006c\u0074\u0042\u006f\u0078');
 const msg = $('\u0072\u0065\u0073\u0075\u006c\u0074\u004d\u0073\u0067');
 const list = $('\u0072\u0065\u0073\u0075\u006c\u0074\u004c\u0069\u0073\u0074');
 box.hidden = false;
 list.innerHTML = '';
 if (result.error) {
 msg.className = '\u0072\u0065\u0073\u0075\u006c\u0074\u002d\u006d\u0073\u0067\u0020\u0065\u0072\u0072\u006f\u0072';
 msg.textContent = '✗ ' + result.error;
 return;
 }
 const total = result.success?.length || 0;
 const skipped = result.skipped?.length || 0;
 msg.className = total > 0 ? '\u0072\u0065\u0073\u0075\u006c\u0074\u002d\u006d\u0073\u0067\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073' : '\u0072\u0065\u0073\u0075\u006c\u0074\u002d\u006d\u0073\u0067\u0020\u0077\u0061\u0072\u006e';
 const batchNote = result.batches > 1 ? ` — ${result.batches} đợt` : '';
 msg.textContent = (result.message || `Xong: ${total} thành công`) + batchNote;
 const renamedTo = new Set((result.renamed || []).map(r => r.to));
 (result.success || []).forEach(name => { if (!renamedTo.has(name)) addResultItem(list,'ok',name,''); });
 (result.renamed || []).forEach(r => addResultItem(list,'ok',r.to,`← ${r.from}`));
 (result.skipped || []).forEach(s => addResultItem(list,'\u0073\u006b\u0069\u0070',s.name,s.reason));
}
function addResultItem(list, type, name, sub) {
 const li = document.createElement('li');
 li.className = '\u0072\u0065\u0073\u0075\u006c\u0074\u002d\u0069\u0074\u0065\u006d';
 li.innerHTML = `
 <div class="ri-dot ${type}"></div>
 <div>
 <div class="\u0072\u0069\u002d\u0074\u0065\u0078\u0074">${esc(name)}</div>
 ${sub ? `<div class="\u0072\u0069\u002d\u0073\u0075\u0062">${esc(sub)}</div>` : ''}
 </div>`;
 list.appendChild(li);
}
async function exportCookies() {
 const btn = $('\u0062\u0074\u006e\u0045\u0078\u0070\u006f\u0072\u0074\u0043\u006f\u006f\u006b\u0069\u0065');
 btn.textContent = '…';
 btn.disabled = true;
 try {
 const cookies = await chrome.cookies.getAll({ domain: '\u0071\u0075\u0061\u006e\u0074\u0072\u0069\u0067\u0063\u006e\u002e\u0076\u0072\u002e\u006f\u0072\u0067\u002e\u0076\u006e' });
 const cookieMap = {};
 cookies.forEach(c => { cookieMap[c.name] = c.value; });
 if (!Object.keys(cookieMap).length) {
 showCookieStatus('⚠ Không tìm thấy cookie. Hãy đăng nhập website trước.', '\u0077\u0061\u0072\u006e');
 return;
 }
 const data = JSON.stringify(cookieMap, null, 2);
 const blob = new Blob([data], { type: 'application/json' });
 const url = URL.createObjectURL(blob);
 await chrome.downloads.download({
 url,
 filename: '\u0063\u006f\u006f\u006b\u0069\u0065\u0073\u002e\u006a\u0073\u006f\u006e',
 saveAs: false,
 });
 showCookieStatus(`✓ Đã xuất ${Object.keys(cookieMap).length} cookie → cookies.json`, 'ok');
 toast('✓ Đã xuất cookie — đặt file vào cùng thư mục với UPLOAD.bat');
 } catch (e) {
 showCookieStatus('✗ Lỗi: ' + e.message, '\u0065\u0072\u0072');
 }
 btn.textContent = 'Xuất ↓';
 btn.disabled = false;
}
function showCookieStatus(msg, type) {
 const row = $('\u0063\u006f\u006f\u006b\u0069\u0065\u0053\u0074\u0061\u0074\u0075\u0073');
 const el = $('\u0063\u006f\u006f\u006b\u0069\u0065\u0053\u0074\u0061\u0074\u0075\u0073\u004d\u0073\u0067');
 row.style.display = '\u0066\u006c\u0065\u0078';
 el.textContent = msg;
 el.style.color = type === 'ok' ? 'var(--green)' : type === '\u0077\u0061\u0072\u006e' ? 'var(--yellow)' : 'var(--red)';
}
const CURRENT_VERSION = '1.0.1';
const VERSION_CHECK_URL = 'https://raw.githubusercontent.com/vtpham87/gcn-uploader/main/version.json';
let uploadLocked = false;
function compareVersions(a, b) {
 const pa = a.split('.').map(Number);
 const pb = b.split('.').map(Number);
 for (let i = 0; i < 3; i++) {
 if ((pb[i] || 0) > (pa[i] || 0)) return 1;
 if ((pb[i] || 0) < (pa[i] || 0)) return -1;
 }
 return 0;
}
async function checkForUpdate(silent = true) {
 try {
 const resp = await fetch(VERSION_CHECK_URL + '?t=' + Date.now(), { cache: '\u006e\u006f\u002d\u0073\u0074\u006f\u0072\u0065' });
 if (!resp.ok) throw new Error('\u0048\u0054\u0054\u0050\u0020' + resp.status);
 const data = await resp.json();
 const hasUpdate = compareVersions(CURRENT_VERSION, data.version) > 0;
 const isForced = hasUpdate && data.force === true;
 if (isForced) {
 lockUpload(data);
 } else if (hasUpdate) {
 const { skippedVersion } = await new Promise(r =>
 chrome.storage.local.get(['\u0073\u006b\u0069\u0070\u0070\u0065\u0064\u0056\u0065\u0072\u0073\u0069\u006f\u006e'], r)
 );
 if (skippedVersion !== data.version) showUpdateBanner(data, false);
 } else if (!silent) {
 showUpdateStatus(`✓ Đang dùng phiên bản mới nhất (v${CURRENT_VERSION})`, 'ok');
 }
 chrome.storage.local.set({ lastUpdateCheck: Date.now(), latestVersion: data.version });
 return data;
 } catch (err) {
 if (!silent) showUpdateStatus('Không kiểm tra được: ' + err.message, '\u0065\u0072\u0072');
 return null;
 }
}
function lockUpload(data) {
 uploadLocked = true;
 const panel = $('\u0074\u0061\u0062\u002d\u0075\u0070\u006c\u006f\u0061\u0064');
 panel.innerHTML = `
 <div class="\u0066\u006f\u0072\u0063\u0065\u002d\u0075\u0070\u0064\u0061\u0074\u0065\u002d\u0073\u0063\u0072\u0065\u0065\u006e">
 <div class="\u0066\u0075\u002d\u0069\u0063\u006f\u006e">
 <svg width="40" height="40" viewBox="0 0 24 24" fill="\u006e\u006f\u006e\u0065">
 <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"
 stroke="var(--yellow)" stroke-width="1.5"/>
 <path d="\u004d\u0031\u0032\u0020\u0038\u0076\u0034\u006d\u0030\u0020\u0034\u0068\u002e\u0030\u0031" stroke="var(--yellow)" stroke-width="1.5"
 stroke-linecap="\u0072\u006f\u0075\u006e\u0064" stroke-linejoin="\u0072\u006f\u0075\u006e\u0064"/>
 </svg>
 </div>
 <h2 class="\u0066\u0075\u002d\u0074\u0069\u0074\u006c\u0065">Yêu cầu cập nhật bắt buộc</h2>
 <p class="\u0066\u0075\u002d\u0076\u0065\u0072\u0073\u0069\u006f\u006e">Phiên bản hiện tại: <strong>v${CURRENT_VERSION}</strong></p>
 <p class="\u0066\u0075\u002d\u0076\u0065\u0072\u0073\u0069\u006f\u006e">Phiên bản mới: <strong>v${data.version}</strong></p>
 ${data.notes ? `<p class="\u0066\u0075\u002d\u006e\u006f\u0074\u0065\u0073">${escHtml(data.notes)}</p>` : ''}
 <p class="\u0066\u0075\u002d\u0064\u0065\u0073\u0063">Chức năng upload đã bị tạm khóa.<br>Vui lòng cập nhật để tiếp tục sử dụng.</p>
 <button class="\u0062\u0074\u006e\u002d\u0066\u0075\u002d\u0075\u0070\u0064\u0061\u0074\u0065" id="\u0062\u0074\u006e\u0046\u006f\u0072\u0063\u0065\u0055\u0070\u0064\u0061\u0074\u0065">
 <svg width="14" height="14" viewBox="0 0 24 24" fill="\u006e\u006f\u006e\u0065">
 <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"
 stroke="\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0043\u006f\u006c\u006f\u0072" stroke-width="1.5" stroke-linecap="\u0072\u006f\u0075\u006e\u0064"/>
 <path d="\u004d\u0033\u0020\u0033\u0076\u0035\u0068\u0035" stroke="\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0043\u006f\u006c\u006f\u0072" stroke-width="1.5" stroke-linecap="\u0072\u006f\u0075\u006e\u0064" stroke-linejoin="\u0072\u006f\u0075\u006e\u0064"/>
 </svg>
 Tải bản mới v${data.version}
 </button>
 <p class="\u0066\u0075\u002d\u0068\u0069\u006e\u0074">Sau khi tải về: giải nén → vào edge://extensions/ → Load unpacked</p>
 </div>
 `;
 $('\u0062\u0074\u006e\u0046\u006f\u0072\u0063\u0065\u0055\u0070\u0064\u0061\u0074\u0065').onclick = () => {
 chrome.downloads.download({
 url: data.download_url,
 filename: '\u0067\u0063\u006e\u002d\u0075\u0070\u006c\u006f\u0061\u0064\u0065\u0072\u002d' + data.version + '.zip',
 saveAs: false,
 });
 chrome.tabs.create({ url: 'edge://extensions/' });
 };
 if ($('\u0075\u0070\u0064\u0061\u0074\u0065\u0042\u0061\u006e\u006e\u0065\u0072')) $('\u0075\u0070\u0064\u0061\u0074\u0065\u0042\u0061\u006e\u006e\u0065\u0072').style.display = '\u006e\u006f\u006e\u0065';
}
function showUpdateBanner(data, isForced) {
 const banner = $('\u0075\u0070\u0064\u0061\u0074\u0065\u0042\u0061\u006e\u006e\u0065\u0072');
 if (!banner) return;
 $('\u0075\u0070\u0064\u0061\u0074\u0065\u004d\u0073\u0067').textContent = `Bản mới: v${data.version}` + (data.notes ? ` — ${data.notes}` : '');
 banner.style.display = '\u0066\u006c\u0065\u0078';
 if ($('\u0062\u0074\u006e\u0055\u0070\u0064\u0061\u0074\u0065\u0053\u006b\u0069\u0070')) $('\u0062\u0074\u006e\u0055\u0070\u0064\u0061\u0074\u0065\u0053\u006b\u0069\u0070').style.display = isForced ? '\u006e\u006f\u006e\u0065' : '';
 $('\u0062\u0074\u006e\u0055\u0070\u0064\u0061\u0074\u0065\u004e\u006f\u0077').onclick = () => {
 chrome.downloads.download({
 url: data.download_url,
 filename: '\u0067\u0063\u006e\u002d\u0075\u0070\u006c\u006f\u0061\u0064\u0065\u0072\u002d' + data.version + '.zip',
 saveAs: false,
 });
 chrome.tabs.create({ url: 'edge://extensions/' });
 toast('Đang tải v' + data.version + '… Giải nén rồi Load unpacked lại nhé!');
 if (!isForced) banner.style.display = '\u006e\u006f\u006e\u0065';
 };
 if ($('\u0062\u0074\u006e\u0055\u0070\u0064\u0061\u0074\u0065\u0053\u006b\u0069\u0070')) {
 $('\u0062\u0074\u006e\u0055\u0070\u0064\u0061\u0074\u0065\u0053\u006b\u0069\u0070').onclick = () => {
 chrome.storage.local.set({ skippedVersion: data.version });
 banner.style.display = '\u006e\u006f\u006e\u0065';
 };
 }
}
function showUpdateStatus(msg, type) {
 const row = $('\u0075\u0070\u0064\u0061\u0074\u0065\u0053\u0074\u0061\u0074\u0075\u0073\u0052\u006f\u0077');
 const el = $('\u0075\u0070\u0064\u0061\u0074\u0065\u0053\u0074\u0061\u0074\u0075\u0073\u004d\u0073\u0067');
 if (!row || !el) return;
 row.style.display = '\u0066\u006c\u0065\u0078';
 el.textContent = msg;
 el.style.color = type === 'ok' ? 'var(--green)' : type === '\u0077\u0061\u0072\u006e' ? 'var(--yellow)' : 'var(--red)';
}
function escHtml(s) {
 return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function loadExtInfo() {
 const id = chrome.runtime.id;
 const url = `edge://extensions/?id=${id}`;
 if ($('\u0065\u0078\u0074\u0049\u0064')) $('\u0065\u0078\u0074\u0049\u0064').textContent = id;
 if ($('\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0056\u0065\u0072\u0073\u0069\u006f\u006e')) $('\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0056\u0065\u0072\u0073\u0069\u006f\u006e').textContent = 'v' + CURRENT_VERSION;
 const open = () => chrome.tabs.create({ url });
 $('\u0062\u0074\u006e\u0045\u0078\u0074\u0050\u0061\u0067\u0065').addEventListener('\u0063\u006c\u0069\u0063\u006b', open);
 if ($('\u0062\u0074\u006e\u004f\u0070\u0065\u006e\u0045\u0078\u0074\u0050\u0061\u0067\u0065')) $('\u0062\u0074\u006e\u004f\u0070\u0065\u006e\u0045\u0078\u0074\u0050\u0061\u0067\u0065').addEventListener('\u0063\u006c\u0069\u0063\u006b', open);
 if ($('\u0062\u0074\u006e\u0043\u0068\u0065\u0063\u006b\u0055\u0070\u0064\u0061\u0074\u0065')) {
 $('\u0062\u0074\u006e\u0043\u0068\u0065\u0063\u006b\u0055\u0070\u0064\u0061\u0074\u0065').addEventListener('\u0063\u006c\u0069\u0063\u006b', async () => {
 $('\u0062\u0074\u006e\u0043\u0068\u0065\u0063\u006b\u0055\u0070\u0064\u0061\u0074\u0065').textContent = '…';
 $('\u0062\u0074\u006e\u0043\u0068\u0065\u0063\u006b\u0055\u0070\u0064\u0061\u0074\u0065').disabled = true;
 await checkForUpdate(false);
 $('\u0062\u0074\u006e\u0043\u0068\u0065\u0063\u006b\u0055\u0070\u0064\u0061\u0074\u0065').textContent = 'Kiểm tra';
 $('\u0062\u0074\u006e\u0043\u0068\u0065\u0063\u006b\u0055\u0070\u0064\u0061\u0074\u0065').disabled = false;
 });
 }
 chrome.storage.local.get(['\u006c\u0061\u0073\u0074\u0055\u0070\u0064\u0061\u0074\u0065\u0043\u0068\u0065\u0063\u006b'], ({ lastUpdateCheck }) => {
 const SIX_HOURS = 6 * 60 * 60 * 1000;
 const shouldCheck = !lastUpdateCheck || (Date.now() - lastUpdateCheck > SIX_HOURS);
 if (shouldCheck) checkForUpdate(true);
 });
}
function setupListeners() {
 document.querySelectorAll('.tab').forEach(t => {
 t.addEventListener('\u0063\u006c\u0069\u0063\u006b', () => {
 document.querySelectorAll('.tab').forEach(x => x.classList.remove('\u0061\u0063\u0074\u0069\u0076\u0065'));
 document.querySelectorAll('.panel').forEach(x => x.classList.remove('\u0061\u0063\u0074\u0069\u0076\u0065'));
 t.classList.add('\u0061\u0063\u0074\u0069\u0076\u0065');
 $('\u0074\u0061\u0062\u002d' + t.dataset.tab).classList.add('\u0061\u0063\u0074\u0069\u0076\u0065');
 if (t.dataset.tab === '\u0068\u0069\u0073\u0074\u006f\u0072\u0079') renderHistory();
 if (t.dataset.tab === '\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u0073') applySettingsUI();
 });
 });
 $('\u0062\u0074\u006e\u0053\u0063\u0061\u006e\u0046\u006f\u006c\u0064\u0065\u0072').addEventListener('\u0063\u006c\u0069\u0063\u006b', e => { e.stopPropagation(); $('\u0066\u006f\u006c\u0064\u0065\u0072\u0049\u006e\u0070\u0075\u0074').click(); });
 $('\u0066\u006f\u006c\u0064\u0065\u0072\u0049\u006e\u0070\u0075\u0074').addEventListener('\u0063\u0068\u0061\u006e\u0067\u0065', async e => {
 const files = Array.from(e.target.files);
 if (!files.length) return;
 const folderName = getFolderName(files);
 chrome.storage.local.set({ lastFolderPath: folderName });
 setFolderPathUI(folderName);
 await loadTodayNames(); 
 await scanAndQueue(files);
 e.target.value = '';
 });
 $('\u0062\u0074\u006e\u004d\u0061\u006e\u0075\u0061\u006c').addEventListener('\u0063\u006c\u0069\u0063\u006b', e => { e.stopPropagation(); $('\u0066\u0069\u006c\u0065\u0049\u006e\u0070\u0075\u0074').click(); });
 $('\u0066\u0069\u006c\u0065\u0049\u006e\u0070\u0075\u0074').addEventListener('\u0063\u0068\u0061\u006e\u0067\u0065', async e => {
 const files = Array.from(e.target.files);
 if (!files.length) return;
 await loadTodayNames();
 for (const file of files) {
 if (!file.type.startsWith('image/')) continue;
 if (queue.find(q => q.file.name === file.name && q.file.size === file.size)) continue;
 const v = validate(file.name);
 if (!v.valid) continue;
 const dataUrl = await readDataUrl(file);
 queue.push({ id: Date.now()+Math.random(), file, dataUrl, originalName: file.name, uploadName: v.uploadName, status: v.status, valid: true });
 }
 renderQueue(); updateBtn();
 e.target.value = '';
 });
 $('\u0062\u0074\u006e\u0055\u0070\u006c\u006f\u0061\u0064').addEventListener('\u0063\u006c\u0069\u0063\u006b', startUpload);
 $('\u0062\u0074\u006e\u0043\u006c\u0065\u0061\u0072\u0051\u0075\u0065\u0075\u0065').addEventListener('\u0063\u006c\u0069\u0063\u006b', () => {
 queue = [];
 $('\u0073\u0063\u0061\u006e\u0053\u0075\u006d\u006d\u0061\u0072\u0079').hidden = true;
 renderQueue(); updateBtn();
 });
 $('\u0062\u0074\u006e\u0043\u006c\u0065\u0061\u0072\u0048\u0069\u0073\u0074\u006f\u0072\u0079').addEventListener('\u0063\u006c\u0069\u0063\u006b', () => {
 chrome.runtime.sendMessage({ type: '\u0043\u004c\u0045\u0041\u0052\u005f\u0054\u004f\u0044\u0041\u0059' }, () => {
 todayNames = []; renderHistory(); toast('Đã xóa lịch sử hôm nay');
 });
 });
 $('\u0062\u0074\u006e\u0053\u0061\u0076\u0065').addEventListener('\u0063\u006c\u0069\u0063\u006b', saveSettings);
 $('\u0065\u0072\u0072\u006f\u0072\u0041\u0063\u0074\u0069\u006f\u006e').addEventListener('\u0063\u0068\u0061\u006e\u0067\u0065', togglePrefixRow);
 if ($('\u0062\u0074\u006e\u0045\u0078\u0070\u006f\u0072\u0074\u0043\u006f\u006f\u006b\u0069\u0065')) $('\u0062\u0074\u006e\u0045\u0078\u0070\u006f\u0072\u0074\u0043\u006f\u006f\u006b\u0069\u0065').addEventListener('\u0063\u006c\u0069\u0063\u006b', exportCookies);
}
function getExt(n) { const i = n.lastIndexOf('.'); return i >= 0 ? n.slice(i) : ''; }
function getBase(n) { const i = n.lastIndexOf('.'); return i >= 0 ? n.slice(0, i) : n; }
function fmtSize(b) {
 if (b < 1024) return b + ' B';
 if (b < 1048576) return (b/1024).toFixed(1) + ' KB';
 return (b/1048576).toFixed(2) + ' MB';
}
function esc(s) {
 return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function readDataUrl(file) {
 return new Promise((res, rej) => {
 const r = new FileReader();
 r.onload = () => res(r.result);
 r.onerror = () => rej(new Error('Không đọc được file'));
 r.readAsDataURL(file);
 });
}
function badgeInfo(status) {
 if (status === '\u0072\u0065\u006e\u0061\u006d\u0065\u0064') return { cls: '\u0072\u0065\u006e\u0061\u006d\u0065\u0064', text: 'Đổi tên' };
 return { cls: 'ok', text: '✓ OK' };
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
let _tt;
function toast(msg) {
 document.querySelectorAll('.toast').forEach(t => t.remove());
 clearTimeout(_tt);
 const d = document.createElement('\u0064\u0069\u0076');
 d.className = '\u0074\u006f\u0061\u0073\u0074'; d.textContent = msg;
 document.body.appendChild(d);
 _tt = setTimeout(() => d.remove(), 2400);
}